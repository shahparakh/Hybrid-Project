package com.example.hands_on_8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
