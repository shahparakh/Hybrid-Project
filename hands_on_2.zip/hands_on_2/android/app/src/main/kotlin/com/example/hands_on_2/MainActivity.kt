package com.example.hands_on_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
